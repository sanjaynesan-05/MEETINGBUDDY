# Revised IEEE paper source

`IEEE_Paper_Sanjay_Nesan_J_updated.tex` is an updated copy of the supplied LaTeX source. The five PNG assets are included beside it so the figure paths resolve when compiled from this directory.

## Compile

Compile twice with a LaTeX distribution that includes IEEEtran:

```powershell
pdflatex IEEE_Paper_Sanjay_Nesan_J_updated.tex
pdflatex IEEE_Paper_Sanjay_Nesan_J_updated.tex
```

The current environment did not expose `pdflatex`, `latexmk`, or `tectonic`, so a compiled PDF could not be produced here. Review the generated PDF for two-column figure/table placement, legibility, page balance, and reference numbering.

## Before submission

The source deliberately preserves TODOs rather than inventing results. Collect or resolve:

- 30–50 labeled retrieval queries; compare MongoDB keyword, Qdrant vector, and RRF (k=60) with MRR, NDCG@5, and Recall@5.
- Expand extraction evaluation to 10–15 meetings, and verify the Tamil audio language/transcript.
- Run at least three paired sequential/parallel timings and report mean ± standard deviation, retry counts, queue/worker settings, model parallelism, context, and offload configuration.
- Recompute grounding flagged rates at 10%, 20%, 30%, 40%, and 50%; run two-annotator support judgments with precision, recall, and Cohen's kappa.
- Run the single-prompt and optional larger-local-model baselines; evaluate the revised risk prompt on the same labels.
- Reconcile the extraction benchmark's four unanswered-question references/predictions with the system inventory's twelve items and verify the 24 ms latency total difference.
- Complete sourced product-feature comparisons if they are retained. Check the bibliography against the primary sources and the final conference's current template requirements.

The supplied screenshot assets are actual application views. The explicit Fig. 2 placeholder sentence was removed, and each of Figs. 2–5 has a distinct caption.
